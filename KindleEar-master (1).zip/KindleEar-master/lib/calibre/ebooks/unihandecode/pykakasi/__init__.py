from calibre.ebooks.unihandecode.pykakasi.kakasi import kakasi
kakasi

__all__ = ["pykakasi"]

